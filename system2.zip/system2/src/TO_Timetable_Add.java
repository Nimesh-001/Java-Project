import javax.swing.*;

public class TO_Timetable_Add {
    public JPanel panal1;
    private JButton logoutButton;
    private JButton attendenceButton;
    private JButton timetableButton;
    private JButton noticeButton;
    private JButton medicalButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JLabel TT_id;
    private JLabel Content;
    private JLabel Description;
    private JButton addButton;
}
