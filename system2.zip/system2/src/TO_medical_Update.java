import javax.swing.*;

public class TO_medical_Update {
    public JPanel panal1;
    private JButton logoutButton;
    private JButton attendenceButton;
    private JButton timetableButton;
    private JButton noticeButton;
    private JButton medicalButton;
    private JTextField textField1;
    private JTextField textField4;
    private JLabel Medical_id;
    private JLabel Student_ID;
    private JButton updateButton;
    private JTextField textField8;
    private JTextField textField9;
    private JLabel Course_code;
    private JLabel Status;
}
