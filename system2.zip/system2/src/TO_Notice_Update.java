import javax.swing.*;

public class TO_Notice_Update {
    public JPanel panal1;
    private JButton logoutButton;
    private JButton attendenceButton;
    private JButton timetableButton;
    private JButton noticeButton;
    private JButton medicalButton;
    private JTextField textField4;
    private JLabel Notice_Id;
    private JButton viewButton;
    private JButton updateButton1;
    private JPanel Edit;
}
