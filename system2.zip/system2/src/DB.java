import java.sql.*;
public class DB {
        public static void main(String[] args) {

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/annex","root","1234");
                Statement st=con.createStatement();
                ResultSet rs=st.executeQuery("select * from crew");
                while(rs.next()){
                    //rs.getString(1);//base form this is how get data from database;
                    System.out.println(rs.getString(1)+" , "+rs.getString(2)+" , "+rs.getString(3));
                }
                con.close();
            }catch(ClassNotFoundException e) {
                System.out.println("Driver not found");
            }catch(SQLException e){
                System.out.println("Connection error");
            }


        }
        }

