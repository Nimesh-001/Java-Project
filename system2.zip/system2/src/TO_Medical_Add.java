import javax.swing.*;

public class TO_Medical_Add {
    public JPanel panal1;
    private JButton logoutButton;
    private JButton attendenceButton;
    private JButton timetableButton;
    private JButton noticeButton;
    private JButton medicalButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JTextField textField7;
    private JLabel Medical_id;
    private JLabel Submission_Date;
    private JLabel Session_Type;
    private JLabel status;
    private JLabel Start_Date;
    private JLabel End_Date;
    private JLabel Reason;
    private JButton addButton;
    private JTextField textField8;
    private JTextField textField9;
    private JTextField textField10;
    private JLabel Course_code;
    private JLabel Student_ID;
    private JLabel TO_ID;
}
