import javax.swing.*;

public class TO_Notice_Add {
    public JPanel panal1;
    private JButton logoutButton;
    private JButton attendenceButton;
    private JButton timetableButton;
    private JButton noticeButton;
    private JButton medicalButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JLabel Notice_id;
    private JLabel Date;
    private JLabel Description;
    private JButton addButton;
}
